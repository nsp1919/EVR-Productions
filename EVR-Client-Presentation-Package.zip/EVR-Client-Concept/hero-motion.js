'use strict';

(() => {
  const story = document.querySelector('.hero-story');
  const stage = story.querySelector('.hero-stage');
  const intro = story.querySelector('.hero-copy');
  const cards = Array.from(story.querySelectorAll('.scene-card'));
  const gallery = story.querySelector('.hero-art');
  const selectors = Array.from(story.querySelectorAll('.card-select'));
  const selectionStatus = document.getElementById('card-selection-status');
  const cardSlots = [0, 1, 2];
  const statement = story.querySelector('.story-statement');
  const insights = story.querySelector('.story-insights');
  const notes = story.querySelector('.story-notes');
  const noteCards = Array.from(notes.querySelectorAll('article'));
  const decisions = story.querySelector('.story-decisions');
  const choices = Array.from(story.querySelectorAll('.story-choice'));
  const chapters = Array.from(story.querySelectorAll('[data-chapter]'));
  const meter = story.querySelector('.story-meter span');
  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  const home = document.getElementById('home');
  let metrics;
  let frame = 0;
  let needsMeasure = true;
  let swapTimer;

  const clamp = value => Math.max(0, Math.min(1, value));
  const mix = (start, end, amount) => start + (end - start) * amount;
  const phase = (value, start, end) => {
    const t = clamp((value - start) / (end - start));
    return t * t * (3 - 2 * t);
  };

  function updateCardControls(enabled) {
    story.classList.toggle('can-select-cards', enabled);
    selectors.forEach((button, index) => {
      button.disabled = !enabled;
      button.setAttribute('aria-pressed', String(cardSlots[index] === 2));
      cards[index].dataset.slot = String(cardSlots[index]);
    });
    gallery.setAttribute('aria-hidden', String(!enabled));
  }

  function finishSwap() {
    clearTimeout(swapTimer);
    story.classList.remove('is-switching-card');
  }

  selectors.forEach((button, index) => button.addEventListener('click', () => {
    if (button.disabled || cardSlots[index] === 2) return;
    const previousFront = cardSlots.indexOf(2);
    const previousSlot = cardSlots[index];
    cardSlots[index] = 2;
    cardSlots[previousFront] = previousSlot;
    finishSwap();
    story.classList.add('is-switching-card');
    updateCardControls(true);
    selectionStatus.textContent = `${cards[index].querySelector('figcaption').textContent} is now in front.`;
    requestRender();
    swapTimer = setTimeout(finishSwap, 650);
  }));

  function measure() {
    const rect = stage.getBoundingClientRect();
    const top = parseFloat(getComputedStyle(stage).top) || 0;
    metrics = {
      width: rect.width,
      height: rect.height,
      start: story.getBoundingClientRect().top + scrollY - top,
      travel: Math.max(1, story.offsetHeight - stage.offsetHeight),
      mobile: innerWidth <= 700,
    };
    needsMeasure = false;
  }

  function render() {
    frame = 0;
    if (home.hidden || !story.classList.contains('is-animated')) return;
    if (needsMeasure) measure();
    const { width, height, start, travel, mobile } = metrics;
    const progress = clamp((scrollY - start) / travel);
    const gather = phase(progress, 0.015, 0.21);
    const expand = phase(progress, 0.20, 0.49);
    const depart = phase(progress, 0.50, 0.61);
    const introExit = phase(progress, 0.02, 0.18);
    const statementIn = phase(progress, 0.30, 0.46);
    const statementOut = phase(progress, 0.50, 0.59);
    const insightIn = phase(progress, 0.56, 0.62);
    const insightOut = phase(progress, 0.68, 0.72);
    const notesIn = phase(progress, 0.70, 0.77);
    const notesOut = phase(progress, 0.82, 0.86);
    const ending = phase(progress, 0.83, 0.93);
    updateCardControls(progress < .16);

    story.dataset.progress = progress.toFixed(4);
    story.dataset.phase = progress < .24 ? 'intro' : progress < .56 ? 'stories' : progress < .72 ? 'perspective' : progress < .86 ? 'notes' : 'choices';
    intro.style.opacity = String(1 - introExit);
    intro.style.transform = mobile
      ? `translateY(${-introExit * 42}px)`
      : `translate(-${introExit * 30}px, calc(-50% - ${introExit * 55}px))`;
    intro.inert = introExit > 0.95;
    intro.setAttribute('aria-hidden', String(introExit > 0.95));

    const initialX = mobile ? [.33, .68, .5, .45, .55, .5] : [.68, .84, .76, .73, .77, .75];
    const initialY = mobile ? [.72, .72, .69, .69, .69, .69] : [.47, .49, .44, .45, .45, .45];
    const spreadX = mobile ? [.18, .5, .82, .18, .5, .82] : [.12, .5, .88, .13, .5, .87];
    const spreadY = mobile ? [.18, .13, .18, .73, .79, .73] : [.20, .18, .21, .72, .75, .72];
    const initialAngle = [-12, 11, -1, 7, -6, 3];
    const finalAngle = [-9, 4, 10, 8, -5, -9];
    const stackedX = [.44, .56, .5, .48, .52, .5];
    const stackedY = [.51, .51, .48, .43, .45, .46];
    cards.forEach((card, index) => {
      const slot = index < 3 ? cardSlots[index] : index;
      const stacked = mix(initialX[slot], stackedX[slot], gather);
      const x = mix(stacked, spreadX[index], expand);
      const y = mix(mix(initialY[slot], stackedY[slot], gather), spreadY[index], expand);
      const scale = mix(slot === 2 ? 1 : .88, mobile ? .67 : .68, expand) * mix(1, 1.08, depart);
      const angle = mix(initialAngle[slot], finalAngle[index], expand);
      const outwardX = (spreadX[index] - .5) * width * .28 * depart;
      const outwardY = (spreadY[index] - .48) * height * .32 * depart;
      card.style.left = '0';
      card.style.top = '0';
      card.style.transform = `translate3d(${x * width + outwardX}px, ${y * height + outwardY}px, 0) translate(-50%, -50%) rotate(${angle}deg) scale(${scale})`;
      card.style.opacity = String((index < 3 ? 1 : phase(progress, .12 + index * .012, .28 + index * .012)) * (1 - depart));
    });

    statement.style.opacity = String(statementIn * (1 - statementOut));
    statement.style.transform = `translate(-50%, calc(-50% + ${(1 - statementIn) * 35 - statementOut * 65}px)) scale(${mix(.95, 1, statementIn)})`;
    insights.style.opacity = String(insightIn * (1 - insightOut));
    insights.style.transform = `translateY(${(1 - insightIn) * 45 - insightOut * 60}px)`;
    insights.setAttribute('aria-hidden', String(insightIn < .95 || insightOut > .05));
    notes.style.opacity = String(notesIn * (1 - notesOut));
    notes.setAttribute('aria-hidden', String(notesIn < .95 || notesOut > .05));
    noteCards.forEach((card, index) => {
      const arrival = phase(progress, .70 + index * .009, .76 + index * .009);
      card.style.transform = `translateY(${(1 - arrival) * (65 + index * 20) - notesOut * (40 + index * 16)}px)`;
    });
    decisions.style.opacity = String(ending);
    decisions.style.transform = `translateY(${(1 - ending) * 40}px)`;
    decisions.inert = ending < .95;
    decisions.setAttribute('aria-hidden', String(ending < .95));
    choices.forEach((choice, index) => {
      const arrival = phase(progress, .84 + index * .025, .925 + index * .025);
      choice.style.opacity = String(arrival);
      choice.style.transform = `translateY(${(1 - arrival) * 40}px)`;
    });
    chapters.forEach((chapter, index) => {
      chapter.classList.toggle('current', index === (progress < .24 ? 0 : progress < .86 ? 1 : 2));
    });
    meter.style.transform = `scaleX(${progress})`;
  }

  function requestRender(measureAgain = false) {
    needsMeasure = needsMeasure || measureAgain;
    if (!frame) frame = requestAnimationFrame(render);
  }

  function configure() {
    finishSwap();
    const enabled = !preference.matches && !(innerWidth <= 700 && innerHeight < 700);
    story.classList.toggle('is-animated', enabled);
    if (!enabled) {
      for (const element of [intro, ...cards, statement, insights, notes, ...noteCards, decisions, ...choices, meter]) element.removeAttribute('style');
      insights.setAttribute('aria-hidden', 'true');
      notes.setAttribute('aria-hidden', 'true');
      intro.inert = false;
      intro.removeAttribute('aria-hidden');
      decisions.inert = true;
      decisions.setAttribute('aria-hidden', 'true');
      story.dataset.progress = '0';
      story.dataset.phase = 'static';
      chapters.forEach((chapter, index) => chapter.classList.toggle('current', index === 0));
      updateCardControls(true);
    }
    requestRender(true);
  }

  document.getElementById('skip-hero').addEventListener('click', () => {
    const target = document.getElementById('home-services');
    target.focus({ preventScroll: true });
    target.scrollIntoView({ behavior: preference.matches ? 'auto' : 'smooth', block: 'start' });
  });
  addEventListener('scroll', () => {
    finishSwap();
    requestRender();
  }, { passive: true });
  addEventListener('resize', configure);
  addEventListener('hashchange', () => requestRender(true));
  addEventListener('load', () => requestRender(true));
  preference.addEventListener('change', configure);
  new ResizeObserver(() => requestRender(true)).observe(stage);
  configure();
})();
